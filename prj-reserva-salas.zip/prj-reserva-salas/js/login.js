$(document).ready(function () {
    $.post('../controller/login.php', {func: "getNameAndTime"}, function (data) {
        console.log(data.name); // John
        console.log(data.time); // 2pm
    }, "json");
//    $.ajax({
//        url: "test.html",
//        context: document.body
//    }).done(function () {
//        $(this).addClass("done");
//    });
    var form = $("form#login");
    alert('echo');
    form.ajax(function () {
        alert(1);
        console.info(form);
        $.ajax({
            type: "POST",
            url: '../controller/login.php',
            data: form.serialize(),
            success: function (response) {
                console.log(form);
                console.log(response);
            }
        });
    });
});
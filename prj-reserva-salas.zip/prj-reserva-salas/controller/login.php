<?php

include '../model/dao.class.php';
var_dump($_POST);
var_dump($_GET);
switch ($_POST) {
    case 'login':
        var_dump($_POST);
        die('end the bug');

        break;

    default:
        break;
}

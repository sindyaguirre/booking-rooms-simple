<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>Reserva de salas</title>
        <!-- Incluindo o CSS do Bootstrap -->
        <link href="../js/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" media="screen" />
        <link rel="stylesheet" type="text/css" media="screen"
              href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">

        <!-- Incluindo o jQuery que é requisito do JavaScript do Bootstrap localmente-->
        <script src="../js/jquery-3.2.1.min.js" type="text/javascript"></script>

        <!-- Incluindo o JavaScript do Bootstrap -->
        <script src="../js/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
        <script src="../js/login.js"></script>
        <script type="text/javascript">

        </script>

    </head>
    <body>
        <form id="formLogin" name="formLogin" class="center-block form-horizontal" method="post">

            <div class="control-group">
                <label class="control-label" for="Login">Login</label>
                <div class="controls">
                    <input id="login" name="login" type="text"
                           placeholder="Login" />
                </div>
                <label class="control-label" for="password">Password</label>
                <div class="controls">
                    <input id="password" name="password" type="password"
                           placeholder="*****" />
                </div>
            </div>

            <div class="control-group">
                <div class="controls">
                    <button class="btn btn-primary" id="btOperacao" name="btOperacao"
                            type="submit" value="Logar" >Logar</button>
                </div>
            </div>

        </form>

    </body>
</html>